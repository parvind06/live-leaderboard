import React from 'react';
import Leaderboard from './components/Leaderboard';

function App() {
  return (
    <div className="App">
      <Leaderboard />
    </div>
  );
}

export default App;