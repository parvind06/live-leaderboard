import mongoose from 'mongoose';

const playerSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  region: { type: String },
  gameMode: { type: String },
}, { timestamps: true });

export const Player = mongoose.model('Player', playerSchema);