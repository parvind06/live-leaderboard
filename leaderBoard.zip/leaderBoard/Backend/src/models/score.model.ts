import mongoose from 'mongoose';

const scoreSchema = new mongoose.Schema({
  player: { type: mongoose.Schema.Types.ObjectId, ref: 'Player', required: true },
  score: { type: Number, required: true, default: 0 },
  updatedAt: { type: Date, default: Date.now, expires: 86400 }, // TTL 24hr
});

export const Score = mongoose.model('Score', scoreSchema);