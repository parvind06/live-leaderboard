// backend/src/index.ts
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import http from 'http';
import WebSocket, { WebSocketServer } from 'ws'; 
import leaderboardRoutes from './route/leaderboard.routes';
import { connectMongoDB } from './config/db';
import { leaderboardManager } from './services/leaderboard.service';
import { startSimulation } from './controller/simulation';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use('/', leaderboardRoutes);

const server = http.createServer(app);
const wss = new WebSocketServer({ server });
leaderboardManager['wss'] = wss;

wss.on('connection', ws => {
  console.log('Client connected');
  ws.on('close', () => console.log('Client disconnected'));
});

const PORT = process.env.PORT || 3000;

(async () => {
  await connectMongoDB(process.env.MONGO_URI || 'mongodb://localhost:27017/leaderboard');
  server.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
    startSimulation();
    setInterval(() => leaderboardManager.broadcastLeaderboard(), 2000);
  });
})();