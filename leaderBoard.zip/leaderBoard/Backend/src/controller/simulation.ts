// backend/src/controllers/simulation.controller.ts
import { leaderboardManager } from '../services/leaderboard.service';

const players = ['Alice', 'Bob', 'Charlie', 'David', 'Eve'];

function getRandomPlayer() {
  return players[Math.floor(Math.random() * players.length)];
}

function getRandomScore() {
  return Math.floor(Math.random() * 100) + 1;
}

export async function startSimulation() {
  for (const name of players) {
    await leaderboardManager.increaseScore(name, 0);
  }
  setInterval(async () => {
    const player = getRandomPlayer();
    const score = getRandomScore();
    await leaderboardManager.increaseScore(player, score);
  }, 2000);
}