// backend/src/controllers/leaderboard.controller.ts
import { Request, Response } from 'express';
import { leaderboardManager } from '../services/leaderboard.service';

export const increaseScore = async (req: Request, res: Response): Promise<void> => {
  const { player, score, region, gameMode } = req.body;

  if (!player || typeof score !== 'number') {
    res.status(400).json({ error: 'Invalid input' });
    return;
  }

  try {
    await leaderboardManager.increaseScore(player, score, region, gameMode);
    res.json({ message: 'Score increased successfully' });
  } catch (error) {
    console.error('Error increasing score:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const getLeaderboard = async (req: Request, res: Response): Promise<void> => {
  const count = parseInt(req.query.count as string, 10) || 100;

  try {
    const data = await leaderboardManager.getLeaderboard(count);
    res.json(data);
  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    res.status(500).json({ error: 'Failed to get leaderboard' });
  }
};