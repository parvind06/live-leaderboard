// backend/src/services/leaderboard.service.ts
import Redis from 'ioredis';
import WebSocket, { Server as WSServer } from 'ws';
import { Player } from '../models/player.model';
import { Score } from '../models/score.model';

interface LeaderboardEntry {
  player: string;
  score: number;
}

export class LeaderboardManager {
  private static readonly LEADERBOARD_KEY = 'leaderboard';
  private redis: Redis;
  private wss?: WSServer;

  constructor(redisClient: Redis) {
    this.redis = redisClient;
  }

  setWebSocketServer(wss: WSServer) {
    this.wss = wss;
  }

  async increaseScore(name: string, scoreInc: number, region?: string, gameMode?: string): Promise<void> {
    let player = await Player.findOne({ name });
    if (!player) player = await Player.create({ name, region, gameMode });

    await Score.findOneAndUpdate(
      { player: player._id },
      { $inc: { score: scoreInc }, updatedAt: new Date() },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );

    await this.redis.zincrby(LeaderboardManager.LEADERBOARD_KEY, scoreInc, name);
  }

  async getLeaderboard(count = 100): Promise<LeaderboardEntry[]> {
    const raw = await this.redis.zrevrange(LeaderboardManager.LEADERBOARD_KEY, 0, count - 1, 'WITHSCORES');
    const result: LeaderboardEntry[] = [];
    for (let i = 0; i < raw.length; i += 2) {
      result.push({ player: raw[i], score: parseInt(raw[i + 1], 10) });
    }
    return result;
  }

  async broadcastLeaderboard(): Promise<void> {
    if (!this.wss) return;
    const data = await this.getLeaderboard();
    const msg = JSON.stringify({ type: 'leaderboard_update', leaderboard: data });
    this.wss.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(msg);
      }
    });
  }
}

// Initialize Redis client
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

// Export manager without WebSocket initially
export const leaderboardManager = new LeaderboardManager(redis);