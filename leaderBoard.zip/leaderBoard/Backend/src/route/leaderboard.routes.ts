// backend/src/routes/leaderboard.routes.ts
import { Router } from 'express';
import { increaseScore, getLeaderboard } from '../controller/LeaderboardManager';

const router = Router();

router.post('/score/increase', increaseScore);
router.get('/leaderboard', getLeaderboard);

export default router;